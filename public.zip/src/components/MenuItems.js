export const MenuItems = [
    {
        title: 'Find Jobs',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Company Reviews',
        url: '#',
        cName: 'nav-links'
    },
    {
        title: 'Find Salaries',
        url: '#',
        cName: 'nav-links'
    },
    // {
    //     title: 'Contact Us',
    //     url: '#',
    //     cName: 'nav-links'
    // },
  

]